package com.demo.algo;

import java.util.Arrays;

/* Java program for Merge Sort */
public class MergeSort 
{
	// Merges two subarrays of arr[].
	// First subarray is arr[l..m]
	// Second subarray is arr[m+1..r]
	int[] array;
	int[] tempMergeArr;
	int length;
	
	public void prepareData(int[] arr) {
		this.array = arr;
		this.length = arr.length;
		this.tempMergeArr = new int[length];
		sort(0,length-1);
		
	}
							//0		0	  1
	void merge(int l, int m, int r)
	{
		
		tempMergeArr = Arrays.copyOf(array, array.length);
		
		int i = l;
		int j = m+1;
		int k = l;
		
		while(i<=m && j<=r) {
			if(tempMergeArr[i] <= tempMergeArr[j]) {
				array[k] = tempMergeArr[i];
				i++;
			}else {
				array[k] = tempMergeArr[j];
				j++;
			}
			k++;
		}
		
		while(i<=m) {
			array[k] = tempMergeArr[i];
			k++;
			i++;
		}
	
		while(j<=r) {
			array[k] = tempMergeArr[j];
			k++;
			j++;
		}
	
		
	}

	// Main function that sorts arr[l..r] using
	// merge()
	void sort(int l, int r)
	{
		if (l < r) {
			// Find the middle point
			int m =l+ (r-l)/2;

			// Sort first and second halves
			sort(l, m);
			sort(m + 1, r);

			// Merge the sorted halves
			merge(l, m, r);
		}
	}

	/* A utility function to print array of size n */
	static void printArray(int arr[])
	{
		int n = arr.length;
		for (int i = 0; i < n; ++i)
			System.out.print(arr[i] + " ");
		System.out.println();
	}

	// Driver code
	public static void main(String args[])
	{
		int arr[] = { 12, 11, 13, 5, 6, 7 };
		//int arr[] = { 1,2,3,4,5,6 };
		
		System.out.println("Given Array");
		printArray(arr);

		MergeSort ob = new MergeSort();
		ob.prepareData(arr);
		
		System.out.println("\nSorted array");
		printArray(arr);
	}
}
