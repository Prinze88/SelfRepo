package com.demo.algo;

import java.util.Arrays;

public class Quicksort {



	public static void main(String[] args) {

		int[] arr = {10,80,30,90,40,50,70};
		System.out.println("Before sort :"+ Arrays.toString(arr));
		quicksort(arr,0,arr.length-1);
		System.out.println("After sort :"+ Arrays.toString(arr));

	}

	private static void quicksort(int[] arr, int i, int j) {

		if(i<j) {
			int low = i;
			int high = j;

			int pi = partition(arr,low,high);
			System.out.println(pi +" "+arr[pi]);

			quicksort(arr, low, pi - 1);
			quicksort(arr, pi + 1, high);
		}
	}

	private static int partition(int[] arr, int low, int high) {

		int i = low -1;
		int pivot = arr[high]; 

		//10,80,30,90,40,50,70

		for(int j=low; j<high; j++) {

			if(arr[j] < pivot) {

				i++;

				int temp = arr[i];
				arr[i] = arr[j];
				arr[j] = temp;
			}
		}

		int temp = arr[i+1];
		arr[i+1] = arr[high];
		arr[high] = temp;

		return i+1;
	}


}
