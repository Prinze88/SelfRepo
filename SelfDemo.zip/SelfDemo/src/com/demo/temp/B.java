package com.demo.temp;

public class B extends A{

	/*
	 * public final void methodA() { System.out.println("Class B main "); }
	 */	
}
