package com.demo.temp;

public interface I1 {

}
