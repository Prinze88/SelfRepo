package com.demo.temp;

public class A {
	
	public final void methodA() {
		System.out.println("Class A main ");
	}
	
}
