package com.demo.string;

public class StringDemo {

	public static void main(String[] args) {
        String s1 = "b";
        String s2 = "c";
        String s3 = new String("a");
        System.out.println("s1: "+s1.hashCode());
        System.out.println("s2: "+s2.hashCode());
        System.out.println("s3: "+s3.hashCode());
    }
	
	
}
