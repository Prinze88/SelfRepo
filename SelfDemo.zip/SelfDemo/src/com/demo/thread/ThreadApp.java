package com.demo.thread;

import java.util.Scanner;

class Processor extends Thread{
	volatile boolean running = true;
	
	@Override
	public void run() {
		while(running) {
			System.out.println("running...");
			try{Thread.sleep(100);}catch(Exception e) {}
		}
	}
	
	public void shutdown() {
		running = false;
	}
}


public class ThreadApp {
	
	public static void main(String[] args) {
		System.out.println("Press enter to stop..");
		
		Processor t1 = new Processor();
		t1.start();
		
		Scanner sc = new Scanner(System.in);
		sc.nextLine();
		
		t1.shutdown();
		
	}
	
}
