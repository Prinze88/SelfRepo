package com.demo.thread;

import java.util.Random;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class DeadlockDemo {

	Account_DLDemo acc1 = new Account_DLDemo();
	Account_DLDemo acc2 = new Account_DLDemo();;

	Lock lock1 = new ReentrantLock();
	Lock lock2 = new ReentrantLock();

	public void firstThread() throws InterruptedException {

		Random r = new Random();
		for(int i=0;i<10000;i++) {

			getLock(lock1,lock2);
			
			try {
				Account_DLDemo.transfer(acc1, acc2, r.nextInt(100));
			}finally {
				lock1.unlock();
				lock2.unlock();
			}
		}
	}

	public void secondThread() throws InterruptedException {
		Random r = new Random();

		for(int i=0;i<10000;i++) {
			
			getLock(lock1,lock2);
			
			try {
				Account_DLDemo.transfer(acc2, acc1, r.nextInt(100));
			}finally {
				lock1.unlock();
				lock2.unlock();
			}
		}
	}

	public void getLock(Lock lock1 ,Lock lock2) throws InterruptedException {

		boolean gotFirstLock = false;
		boolean gotSecondLock = false;

		while(true){
			try {
				gotFirstLock = lock1.tryLock();
				gotSecondLock = lock2.tryLock();
			}finally {
				if(gotFirstLock && gotSecondLock)
					return;
				
				if(gotFirstLock)
					lock1.unlock();
				
				if(gotSecondLock)
					lock2.unlock();
			}
			
			Thread.sleep(1);
		}
	}

	public void finish() {
		System.out.println("Account balance in Acc1 "+acc1.getBalance());
		System.out.println("Account balance in Acc2 "+acc2.getBalance());
		System.out.println("Total balance in Acc1 and Acc2 "+ (acc1.getBalance()+acc2.getBalance()));
	}

}
