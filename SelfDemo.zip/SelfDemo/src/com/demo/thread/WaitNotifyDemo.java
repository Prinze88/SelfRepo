package com.demo.thread;

import java.util.LinkedList;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class WaitNotifyDemo extends Thread{

	LinkedList<Integer> list = new LinkedList<Integer>();
	Lock reLock = new ReentrantLock();
	Condition cond = reLock.newCondition();
	

	Object lock = new Object();
	int val = 0;

	public void produce() throws InterruptedException {
		synchronized (lock) {
			while(list.size()==10) {
				System.out.println("Size full waiting to be consumed");
				lock.wait();
			}
			System.out.println("value produced..");
			list.add(val++);
			lock.notify();
		}

	}


	public void consume() throws InterruptedException {
		synchronized (lock) {
			
			while(list.size()==0) {
				System.out.println("List empty waiting to produce");
				lock.wait();
			}
			
			System.out.println("value consumed..");
			System.out.println(list.removeFirst());
			lock.notify();
		}
		
	}
}
