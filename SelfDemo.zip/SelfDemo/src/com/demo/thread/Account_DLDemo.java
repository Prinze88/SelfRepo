package com.demo.thread;

public class Account_DLDemo {

	int balance = 10000;
	
	public void deposit(int amount) {
		balance += amount;
	}
	
	public void withdraw(int amount) {
		balance -= amount;
	}

	public int getBalance() {
		return balance;
	}
	
	public static void transfer(Account_DLDemo acc1,Account_DLDemo acc2,int amount) {
		acc1.withdraw(amount);
		acc2.deposit(amount);
	}
	
}
