package com.demo.thread;

public class Main {

	public static void main(String[] args) throws InterruptedException {
		LockDemoWorker obj = new LockDemoWorker();
		obj.main();
	}
	
}
