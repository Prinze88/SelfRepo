package com.demo.thread;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

class CountDownProcess extends Thread{
	private CountDownLatch latch ;
	private int id ;
	
	CountDownProcess(CountDownLatch latch,int id){
		this.latch=latch;
		this.id=id;
	}
	
	@Override
	public void run() {
		System.out.println("Task "+id+" started..");
		if(id==1) {
			try {Thread.sleep(10000);} catch (InterruptedException e) {e.printStackTrace();}
			System.out.println("Task "+id+" completed..");
			latch.countDown();
		}else if(id==2) {
			try {Thread.sleep(30000);} catch (InterruptedException e) {e.printStackTrace();}
			System.out.println("Task "+id+" completed..");
			latch.countDown();
		}else {
			try {Thread.sleep(50000);} catch (InterruptedException e) {e.printStackTrace();}
			System.out.println("Task "+id+" completed..");
			latch.countDown();
		}
	
		
		
		
	}
}

public class CountDownDemo {

	public static void main(String[] args) {
		CountDownLatch latch = new CountDownLatch(3);
		ExecutorService execService = Executors.newFixedThreadPool(3);
		for(int i=0;i<3;i++) {
			execService.submit(new CountDownProcess(latch,i));
		}
		
		try {latch.await();} catch (InterruptedException e) {e.printStackTrace();}
		System.out.println("Alll Task completed..");
		execService.shutdown();
	}
}
