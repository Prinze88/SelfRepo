package com.demo.thread;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class LockDemoWorker {
	
	Random random = new Random();
	List<Integer> list1 = new ArrayList<Integer>();
	List<Integer> list2 = new ArrayList<Integer>();
	
	Object lock1 = new Object();
	Object lock2 = new Object();
	
	public void processStage1() {
		synchronized (lock1) {
			try{Thread.sleep(1);}catch(Exception ex) {ex.printStackTrace();}
			list1.add(random.nextInt());
		}
			
	}
	
	public void processStage2() {
		synchronized (lock2) {
			try{Thread.sleep(1);}catch(Exception ex) {ex.printStackTrace();}
			list2.add(random.nextInt());	
		}
			
	}
	
	
	public void doWork(){
		for (int i = 0; i < 1000; i++) {
			processStage1();
			processStage2();
		}
		
	}
	
	public void main() throws InterruptedException {
		long start = System.currentTimeMillis();
		
		Thread t1 = new Thread(new Runnable() {
			@Override
			public void run() {
				doWork();
			}
		});
		
		
		Thread t2 = new Thread(new Runnable() {
			@Override
			public void run() {
				doWork();
			}
		});
		
		t1.start();
		t2.start();
		
		t1.join();
		t2.join();
		
		long end = System.currentTimeMillis();
		System.out.println(end-start);
		System.out.println("List1 size : "+list1.size() +" List2 size : "+list2.size());
		
	}
}

