package com.demo.cal;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class NumberDemoOptimized {
	
	public static List<Integer> shuffle(List<Integer> inputList){
		
		Integer[] inputArr = inputList.toArray(new Integer[0]);
 		
		int l= 0;
		int r=inputArr.length-1;
		int n = inputArr.length;
		
		while(l<r) {
			if(inputArr[l]<0)
				l++;
			
			else if(inputArr[r]>0)
				r--;
			else {
				inputArr= swap(l,r,inputArr);
				
			}
			
		}
		
		
		System.out.println(Arrays.asList(inputArr));
		
		
		if(l==0 || l==n)
			return Arrays.asList(inputArr);
		else {
			int k=0;
			while(k<n && l<n) {
				swap(k, l, inputArr);
				k+=2;
				l++;
			}
		}
		
		System.out.println(Arrays.asList(inputArr));
		return Arrays.asList(inputArr);
	}
	
	public static Integer[] swap(int r,int l,Integer[] arr) {
		
		int temp = arr[r];
		arr[r]= arr[l];
		arr[l]= temp;
		
		return arr;
	}
	
	
	public static void rearrange(List<Integer> input_list) {
		
		
		
	}
	
	
	
	
	
	
	public static void main(String[] args) {
		
		//Input: {-5, -2, 5, 2, 4, 7, 1, 8, 0, -8}
		//Output: {-5, 5, -2, 2, -8, 4, 7, 1, 8, 0}
		
		Integer[] input_arr = {-5, -2, 5, 2, 4, 7, 1, 8, 0, -8};
		List<Integer> input_list = Arrays.asList(input_arr);
		
		rearrange(shuffle(input_list));
		
	}
}
