package com.demo.cal;

public class Main {

	
	public static void main(String[] args) {
		Child ch = new Child();
		
		Parent p = ch;
		
	}
	
}
