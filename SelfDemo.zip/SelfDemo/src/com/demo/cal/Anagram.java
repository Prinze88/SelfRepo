package com.demo.cal;

import java.util.Stack;

public class Anagram {

	public static void main(String[] args) {
		
		String input = "send";
		String output = "dens";
		System.out.println(checkAnagram(input,output));
	}

	private static boolean checkAnagram(String input,String output) {
		
		boolean isAnagram = false;
		
		if(input.length()!=output.length())
			return isAnagram;
		
		Stack<String> inputStack = new Stack<>();
		for(int i=0;i<input.length();i++) {
			inputStack.push(input.charAt(i)+"");
		}
		
		for(int i=0;i<output.length();i++) {
			String temp = output.charAt(i)+"";
			if(inputStack.contains(temp)) {
				inputStack.remove(temp);
			}
		}
		
		if(inputStack.isEmpty())
			isAnagram=true;
		
		return isAnagram;
				
	}

}
