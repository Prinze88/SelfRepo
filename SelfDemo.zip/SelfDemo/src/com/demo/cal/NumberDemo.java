package com.demo.cal;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Stack;

import javax.annotation.PostConstruct;

public class NumberDemo {
	
	public static void rearrange(List<Integer> input_list) {
		
		Stack<Integer> positiveList = new Stack<>();
		Stack<Integer> negativeList = new Stack<>();
		List<Integer> resultList = new ArrayList<>();
		
		boolean negFlag = false;
		boolean posFlag = false;
		
		
		for (int i = 0; i < input_list.size(); i++) {
			if(input_list.get(i) < 0) {
				negativeList.add(input_list.get(i));
			}else if(input_list.get(i) > 0){
				positiveList.add(input_list.get(i));
			}
		}
		
		
		
		//for (int i = 0; i < negativeList.size() || i < positiveList.size(); i++) {
		while(!negativeList.isEmpty() || !positiveList.isEmpty()) {
			if(!negFlag && !negativeList.isEmpty()) {
				resultList.add(negativeList.pop());
				negFlag = true;
				posFlag = false;
			}else if(!posFlag && !positiveList.isEmpty()){
				resultList.add(positiveList.pop());
				posFlag = true;
				negFlag = false;
			}
			
			if(negativeList.isEmpty()) {
				negFlag = true;
				posFlag = false;
			}
			
			if(positiveList.isEmpty()) {
				posFlag = true;
				negFlag = false;
			}
		}
		
		System.out.println(resultList);
		
	}
	
	
	
	
	
	
	public static void main(String[] args) {
		
		//Input: {-5, -2, 5, 2, 4, 7, 1, 8, 0, -8}
		//Output: {-5, 5, -2, 2, -8, 4, 7, 1, 8, 0}
		
		Integer[] input_arr = {-5, -2, 5, 2, 4, 7, 1, 8, 0, -8};
		List<Integer> input_list = Arrays.asList(input_arr);
		
		rearrange(input_list);
		
	}
}
