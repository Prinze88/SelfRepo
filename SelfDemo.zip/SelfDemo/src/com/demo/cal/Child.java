package com.demo.cal;

public class Child extends Parent{

}
