package com.demo.pattern;

public class Child1 extends Parent{

}
