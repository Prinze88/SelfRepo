package com.demo.pattern;

public class Parent {

}
