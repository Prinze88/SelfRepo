package com.demo.pattern;

public class MainDemo {

	final static String A = "000";
	final static String B = "000";
	
	
	public static void m1(Parent p) {
		if(p instanceof Child1) {
			System.out.println("1");
		}
		
		if(p instanceof Child2) {
			System.out.println("2");
		}
	}
	
	
	public static void main(String[] args) {
		
		Parent c1 = new Child1();
		Parent c2 = new Child2();
		
		m1(c1);
		m1(c2);
		
		
		
		if(A==B)
			System.out.println("==");
		
		if(A.equals(B))
			System.out.println("E");
		
	}
	
}
