package com.demo.pattern;

public class Print {

	
	
	public static void printStruct(int n) throws InterruptedException{
		
		int k = 1;
		for(int i=0; i<n; i++) {
			for (int j = 0; j < n; j++) {
				if(j< n-k) {
					//Thread.sleep(250);
					System.out.print(" ");
				}else {
					Thread.sleep(250);	
					System.out.print("* ");
				}
			}
			k++;
			System.out.println();
			
		}
		
		
		
		
	}
	
	
	
	
	public static void main(String[] args) throws InterruptedException {
		printStruct(8);
	}
	
}
