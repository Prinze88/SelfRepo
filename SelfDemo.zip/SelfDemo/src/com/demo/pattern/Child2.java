package com.demo.pattern;

public class Child2 extends Parent{

}
