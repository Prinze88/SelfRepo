package com.demo.java8;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import java.security.GeneralSecurityException;
import java.security.MessageDigest;
import java.util.Base64;


public class Main {
	private static final String SEED = "encyptiondecryptionutility.encyption.seed";
	private static SecretKeySpec secretKey;
	private static String encryptedSeed = "Mv@ppV0d@f0n3k3y";



	public static String decrypt(String strToDecrypt)
	{
		try
		{
			setKey();
			Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5PADDING");
			cipher.init(Cipher.DECRYPT_MODE, secretKey);
			return new String(cipher.doFinal(Base64.getDecoder().decode(strToDecrypt)));
		}
		catch (Exception e)
		{
			System.out.println("Error while decrypting: " + e.toString());
		}
		return null;
	}

	public static void setKey()
	{
		MessageDigest sha = null;
		try {
			/*
			 * if (encryptedSeed == null){ encryptedSeed = Config.getString(SEED,
			 * "Mv@ppV0d@f0n3k3y"); }
			 */
			
			byte[] key = encryptedSeed.getBytes();
			secretKey = new SecretKeySpec(key, "AES");
		}
		catch (Exception e) {
			e.printStackTrace();
		}

	}

	public static String encrypt(String plainText)
			throws Exception {
		byte[] plainTextByte = plainText.getBytes();
		setKey();
		Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5PADDING");
		cipher.init(Cipher.ENCRYPT_MODE, secretKey);
		byte[] encryptedByte = cipher.doFinal(plainTextByte);
		Base64.Encoder encoder = Base64.getEncoder();
		String encryptedText = encoder.encodeToString(encryptedByte);
		return encryptedText;
	}


	public static void main(final String[] args) throws GeneralSecurityException
	{
		try {
			String name = "DHAVAL";
			String number = "8099988877";
			String encryptedName = encrypt(name);
			System.out.println("Encrypted Name String :: " +encryptedName);
			String decryptedName = decrypt(encryptedName) ;
			System.out.println("Descrypted Name String ::: " +decryptedName);
			String encryptedNumber = encrypt(number);
			System.out.println("Encrypted  Number String :: " +encryptedNumber);
			String decryptedNumber = decrypt(encryptedNumber) ;
			System.out.println("Descrypted Name String ::: " +decryptedNumber);
		}catch (Exception e){
			e.printStackTrace();
		}
	}

} 