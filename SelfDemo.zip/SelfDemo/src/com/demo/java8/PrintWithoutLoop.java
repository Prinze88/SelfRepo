package com.demo.java8;

public class PrintWithoutLoop {

	public static void print(int i,int k){
		if(i==k)
			return;
		else {
			i++;
			System.out.println(i);
			print(i,k);
		}
	}
	
	public static void main(String[] args) {
		print(0,5);
	}
	
}
