package com.demo.java8;

public class Addition {

	public static void main(String[] args) {
		
		int a =10, b=2;
		while (b != 0){
            int carry = (a & b) ; //CARRY is AND of two bits
          
            a = a ^b; //SUM of two bits is A XOR B
          
            b = carry << 1; //shifts carry to 1 bit to calculate sum
		}
		
		System.out.println(a);
		
		
	}
	
}
