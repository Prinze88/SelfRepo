package com.demo.java8;

import java.util.Comparator;

public class DesignationSorting implements Comparator<Employee>{
	
	public int compare(Employee o1, Employee o2) {
		
		return o1.getDesignation().compareTo(o2.getDesignation());
		
	};

}
