package com.demo.java8;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

class Address{
	
	String data1 ;
	String data2 ;
	
	public Address(String data1, String data2) {
		super();
		this.data1 = data1;
		this.data2 = data2;
	}

	@Override
	public String toString() {
		return "Address [data1=" + data1 + ", data2=" + data2 + "]";
	}
	
	
	
}


public class Employee implements Comparable<Employee> {

	
	private String name;
	private String designation;
	private double salary;
	private Address address;
	
	
	public Employee(String name, String designation, double salary,Address address) {
		this.name = name;
		this.designation = designation;
		this.salary = salary;
		this.address=address;
	}
	
	public Employee() {
	}

	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((designation == null) ? 0 : designation.hashCode());
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		long temp;
		temp = Double.doubleToLongBits(salary);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Employee other = (Employee) obj;
		if (designation == null) {
			if (other.designation != null)
				return false;
		} else if (!designation.equals(other.designation))
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		if (Double.doubleToLongBits(salary) != Double.doubleToLongBits(other.salary))
			return false;
		return true;
	}

	
	
	@Override
	public String toString() {
		return "Employee [name=" + name + ", designation=" + designation + ", salary=" + salary + ", address=" + address
				+ "]";
	}

	public List<Employee> getEmployees(){
		List<Employee> empList;
		
		Employee emp1 = new Employee("Duke Puke", "Manager", 500000d , new Address("aa","bb"));
		Employee emp2 = new Employee("Dan Bil", "Executive", 400000d, new Address("aa","bb"));
		Employee emp3 = new Employee("Abraham Lin", "President", 950000d, new Address("aa","bb"));
		Employee emp4 = new Employee("Charles Babbage", "Programmer", 800000d, null);
		
		empList = Arrays.asList(emp1,emp2,emp3,emp4);
		return empList;
		
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	@Override
	public int compareTo(Employee o) {
		return this.getName().compareTo(o.getName());
	}
	
	
}
