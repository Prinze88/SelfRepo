package com.demo.java8;

public interface Printer {
	
	public String print();

}
