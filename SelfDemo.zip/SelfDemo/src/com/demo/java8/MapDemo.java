package com.demo.java8;

import java.util.Arrays;
import java.util.List;

public class MapDemo {

	
	public static void main(String[] args) {
		
		List<String> people = Arrays.asList("Foo","Bar","Loreal","Ipsum","Faa","Boo");
		
		people
			.stream()
			.map(String::toLowerCase)
			.filter(x-> x.startsWith("f"))
			.forEach(System.out::println);
		
	}
}
