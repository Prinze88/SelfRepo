package com.demo.java8;

//<applet code=Flag.class height=400 width=400></applet>
import java.applet.Applet;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;

public class Flag extends Applet 
{

   public void paint(Graphics fl)
   {    Color c1=new Color(255,140,0);   //saffron color
        Color c2=new Color(139,0,0);     // dark red color
       //for pole
       fl.setColor(c2);
       fl.fillRect(250,100,5,400);
       fl.setColor(Color.black);
       fl.drawRect(250,100,5,400);
       //for saffron
       fl.setColor(c1);
       fl.fillRect(255,102,180,40);
       fl.setColor(Color.black);
       fl.drawRect(255,102,180,40);
       //for white
       fl.setColor(Color.WHITE);
       fl.fillRect(255,142,180,40);
       fl.setColor(Color.black);
       fl.drawRect(255,142,180,40);
       //for green
       fl.setColor(Color.GREEN);
       fl.fillRect(255,182,180,40);
       fl.setColor(Color.black);
       fl.drawRect(255,182,180,40);
       // for background
       Color c4= new Color(173,216,230);
       setBackground(c4);
       // for stairs
      int j[]={250,245,245,225,225,280,280,260,260,255};
      int k[]={500,500,505,505,515,515,505,505,500,500};
      fl.setColor(c2);
      fl.fillPolygon(j,k,10);
      fl.setColor(Color.BLACK);
      fl.drawPolygon(j,k,10);
      // for ashok chakra
      fl.setColor(Color.blue);
      fl.drawOval(325,142,39,39);
      // for lines in ashok chakra
       int n1=345;               
       int d1=162;
       double n2,d2;

        double angle= 0.0;    //for angle determination

        double line=0.0;

            

             int r=20;

             for(int i=1;i<=24;i++)
                {
                         angle=(double)line*(3.14/180);

                          n2=n1+(double)r*Math.cos(angle);

                          d2=d1+(double)r*Math.sin(angle);

                         fl.drawLine(n1,d1,(int)n2,(int)d2);   //drawing line between (n1,d1) and (n2,d2)

                        line=line+(360/24);
               }
             // for text
             Font f=new Font("Arial",Font.BOLD,36);
             fl.setFont(f);
             Color c3=new Color(0,100,0);
             fl.setColor(c3);
             fl.drawString("Happy Republic Day",240,595);
             
   }
    

}