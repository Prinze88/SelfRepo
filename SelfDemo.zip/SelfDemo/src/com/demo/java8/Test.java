package com.demo.java8;

import java.util.function.BiConsumer;
import java.util.function.Consumer;
import java.util.function.ObjDoubleConsumer;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Test {
	
	public static void main(String[] args) {
		
		Logger logger = Logger.getLogger(Test.class.getName());
		Employee obj = new Employee();
		
		Consumer<Employee> c1 = e-> logger.log(Level.INFO, "{0}",e); 
		
		obj.getEmployees().forEach(emp->{
			if(emp.getSalary()>800000)
				c1.accept(emp);
				
		});
		
		BiConsumer<String, String> biCon = (name,designation) -> System.out.println("Name is "+name+" designation is "+designation);
		
		obj.getEmployees().forEach(emp->{
			biCon.accept(emp.getName(), emp.getDesignation());
		});
		
		
		ObjDoubleConsumer<String> biCon2 = (name,salary) -> System.out.println("Name is "+name+" salary is "+salary);
		obj.getEmployees().forEach(emp->{
			if(emp.getSalary()>50000) {
				biCon2.accept(emp.getName(), emp.getSalary());
			}
		});
		
	}
	
}
