package com.demo.java8;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;

public class StreamDemo {

	public static void main(String[] args) {
		
		
		Employee e1 = 	new Employee("Test", "SE", 100000,new Address("aa","bb"));
		Employee e2 = 	new Employee("Test1", "SE1", 200000,null);
		Employee e3 = 	new Employee("Test2", "SE2", 300000,null);
		
		
		Employee e4 = 	new Employee("Test1", "SE1", 200000,new Address("cc","dd"));
		Employee e5 = 	new Employee("Test2", "SE2", 300000,new Address("ee","ff"));
		
		
		
		List<Employee> listEmp = new ArrayList<Employee>();
		listEmp.add(e1);listEmp.add(e2);listEmp.add(e3);
		
		List<Employee> listEmp2 = new ArrayList<Employee>();
		listEmp2.add(e4);listEmp2.add(e5);
		
		List<Employee> finalList = 
				listEmp2.stream()
				.filter(os-> listEmp.stream()
						.anyMatch(ns-> ns.getName().equals(os.getName())))
				.collect(Collectors.toList());
		
		
		System.out.println(finalList);
		
		
		/*
		 * Double totalDepoRef =
		 * listEmp.stream().mapToDouble(dep->dep.getSalary()).sum();
		 * 
		 * System.out.println("total "+totalDepoRef);
		 * 
		 * 
		 * List<String> temp = new ArrayList<String>();
		 * 
		 * List<String> temp1 = new ArrayList<String>();
		 * 
		 * temp = listEmp.stream().map(emp-> { if(emp.getAddress()!=null) { return
		 * emp.getAddress().data1; } return null;
		 * 
		 * }).collect(Collectors.toList());
		 * 
		 * 
		 * temp = temp.stream().filter(t->t!=null).collect(Collectors.toList());
		 * 
		 * temp1 = listEmp .stream() .filter(emp-> emp.getAddress()!=null) .map(emp ->
		 * emp.getAddress().data1) .collect(Collectors.toList());
		 * 
		 * System.out.println("temp1"+ temp1);
		 * 
		 * AtomicInteger i = new AtomicInteger();
		 * 
		 * listEmp.forEach(t->{ i.incrementAndGet(); });
		 * 
		 * System.out.println("qwerty "+i.get());
		 * 
		 * System.out.println(temp);
		 */
		
		/*
		 * List<String> friendNames = personList.stream()
		 * .flatMap(e->e.getFriends().stream()) .collect(Collectors.toList());
		 */
		
			
		
		
		
		/*
		 * StringBuilder finalStirng = new StringBuilder(); listEmp.stream().forEach(a
		 * ->{ StringBuilder temp = new StringBuilder();
		 * temp.append("'");temp.append(a.getName());temp.append("'");
		 * finalStirng.append(temp.toString()); finalStirng.append(",");
		 * 
		 * });
		 */
		
		
		
	}
	
}
