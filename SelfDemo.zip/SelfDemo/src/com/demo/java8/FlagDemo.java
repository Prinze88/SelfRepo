package com.demo.java8;

import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.geom.Ellipse2D;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.Timer;

public class FlagDemo{
	
	public static void main(String[] args) {
		Ball ball = new Ball();
		JFrame f = new JFrame();
		f.add(ball);
		f.setVisible(true);
		f.setSize(600,400);
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	
}


class Ball  extends JPanel implements ActionListener {
	Timer t = new Timer(5,this);
	double x=0, y=0, velX=2, velY=2;
	
	@Override
	protected void paintComponent(Graphics g) {
		super.paintComponent(g);
		Graphics2D g2 = (Graphics2D)g;
		Ellipse2D el = new Ellipse2D.Double(x,y,40,40);
		g2.fill(el);
		t.start();
		
		
	}
	
	@Override
	public void actionPerformed(ActionEvent arg0) {
		if(x<0 || x>560)
			velX = -velX;
		
		if(y<0 || y>360)
			velY = -velY;
		
		x+=velX;
		y+=velY;
		
		repaint();
		
	}
	
}

