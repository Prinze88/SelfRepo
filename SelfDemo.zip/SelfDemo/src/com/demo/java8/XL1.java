package com.demo.java8;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

public class XL1 {

	public static void main(String[] args) {
		String str = "5.0,100,5.5,101,6.0,102:L10;5.0,99,5.5,100,6.0,101:L20;";

		String[] rowColData = str.split(";");

		Map<String, List<String>> rowWisePriceData = new LinkedHashMap<>();
		List<String> colNames = new ArrayList<>();

		for(String s : rowColData) {

			String[] rowData = s.split(":")[0].split(",");
			colNames.add(s.split(":")[1].replaceAll("[A-Za-z]", ""));
			List<String> val = null;
			for(int i=0;i<rowData.length;i+=2) {
				if(rowWisePriceData.get(rowData[i])==null) {
					val = new ArrayList<>();	
				}else {
					val = rowWisePriceData.get(rowData[i]);
				}
				val.add(rowData[i+1]);
				rowWisePriceData.put(rowData[i], val);
			}

		}

		boolean firstLine = true;
		for(String col: colNames) {
			if(firstLine) {
				System.out.print("\t"+col+"\t");
				firstLine = false;
			}else {
				System.out.println(col+"\t");
			}
		}
		for(Entry<String, List<String>> row : rowWisePriceData.entrySet()) {
			System.out.print(row.getKey()+"\t");
			for(String price : row.getValue()) {
				System.out.print(price+"\t");
			}
			System.out.println();
		}

	}
}
