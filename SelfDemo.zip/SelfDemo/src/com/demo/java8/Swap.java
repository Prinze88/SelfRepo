package com.demo.java8;

public class Swap {

	public static void main(String[] args) {
		
		int i = -87,j=100;
		
		i += j;  
		j = i-j;
		i -= j;
		
		
		System.out.println(j);
		System.out.println(i);
		
	}
}
