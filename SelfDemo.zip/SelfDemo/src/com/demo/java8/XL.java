package com.demo.java8;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.swing.JEditorPane;
import javax.swing.JFrame;

public class XL extends JFrame{
	public static void main(String[] args) {
		XL xl1 = new XL();
		String str = "5.0,99,5.5,100,6.0,101:L20;5.0,100,5.5,101,6.0,102:L10;5.0,99,5.5,100,6.0,101:L20;5.0,99,5.5,100,6.0,101:L20;";
		xl1.display(prepareData(str));
	}
	public static String prepareData(String str){	
		String[] rowColData = str.split(";");
		Map<String, List<String>> rowWisePriceData = new LinkedHashMap<>();
		List<String> colNames = new ArrayList<>();
		for(String s : rowColData) {
			String[] rowData = s.split(":")[0].split(",");
			colNames.add(s.split(":")[1].replaceAll("[A-Za-z]", ""));
			List<String> val = null;
			for(int i=0;i<rowData.length;i+=2) {
				if(rowWisePriceData.get(rowData[i])==null) {
					val = new ArrayList<>();	
				}else {
					val = rowWisePriceData.get(rowData[i]);
				}
				val.add(rowData[i+1]);
				rowWisePriceData.put(rowData[i], val);
			}
		}
		StringBuilder html = new StringBuilder(); 
		html.append("<html><head><title>Tabular Data</title></head><table><tr><td></td>");
		for(String col: colNames) {
			html.append("<th>"+col+"</th>");
		}
		html.append("</tr><tr>");
		for(Entry<String, List<String>> row : rowWisePriceData.entrySet()) {
			html.append("<th>"+row.getKey()+"</th>");
			for(String price : row.getValue()) {
				html.append("<td>"+price+"</td>");
			}
			html.append("</tr>");
		}
		html.append("</table></html>");
		return html.toString();
	}
	public void display(String html) {
		JEditorPane jep = new JEditorPane("text/html",html);
		add(jep);
		setVisible(true);
		setSize(500,500);
		setDefaultCloseOperation(EXIT_ON_CLOSE);		
	}
}