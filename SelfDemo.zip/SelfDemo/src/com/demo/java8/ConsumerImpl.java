package com.demo.java8;

import java.util.Arrays;
import java.util.List;
import java.util.function.Consumer;

public class ConsumerImpl {

	public static void main(String[] args) {
		//Consumer<String> con = (x)-> System.out.println(" 1 "+x.length()+" Value of x is "+x);
		//con.accept("Yo Mama..");
		//Consumer<String> con1 = (x)-> System.out.println(" 2 "+x.length()+" Value of x is "+x);
		//con1.accept("sup");
		//con.andThen(con1).accept("lol");
		//Employee empObj = new Employee();

		//List<Employee> empList = empObj.getEmployees();  
		
		//Consumer<Employee> con = (emp) -> System.out.println(emp);
		//empList.forEach(con);
		
		Consumer<List<Integer>> modify = list -> {
			for(int i=0;i<list.size();i++) {
				list.set(i, 2*list.get(i));
			}
		};
		
		Consumer<List<Integer>> dispListConsumer = list-> System.out.println(list);
		
		List<Integer> intList = Arrays.asList(1,2,3,4,5);
		
		modify.andThen(dispListConsumer).accept(intList);
		
		
	}
}
 