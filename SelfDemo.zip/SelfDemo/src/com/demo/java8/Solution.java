package com.demo.java8;

import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;




public class Solution {
	
	
	public static String temp() {
		

		
		String[] str = { "cat", "dog", "banana", "catdog" ,"dogandcat" };
		
		Arrays.sort(str,new Comparator<String>() {
			
			@Override
			public int compare(String o1, String o2) {
			
				return o2.length()-o1.length();
			}
			
		});
		
		//System.out.println(Arrays.toString(str));
		
		
		for(int i=0;i<str.length;i++) {
			String temp = str[i]; 
			for(int j=i+1;j<str.length;j++) {
				if(temp.startsWith(str[j])) {
					temp = temp.replaceAll(str[j], "");
					
					if(temp.length()==0) {
						return str[i];
					}
				}
			}
			
		}
		return "";
		
	}
	
	public static void main(String[] args) {
		System.out.println(temp());
		
	}
	
} 

