package com.demo.java8;

import java.util.function.IntPredicate;
import java.util.function.Predicate;

public class PredicateExample {

	public static void main(String[] args) {
		
		IntPredicate p1 = i -> i>10;
		IntPredicate p2 = i -> i%2==0;
		
		Predicate<Employee> p3 = emp -> emp.getSalary()>400000;
		
		new Employee().getEmployees().forEach(emp->{
			if(p3.test(emp)) {
				System.out.println(emp);
			}
		});
		
		
		
		
		//System.out.println(p1.or(p2).test(19));
		
	}
}
