package com.demo.java8;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class Java8Demo {
	
	
	
    private static final DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

	public static void main(String[] args) {
		
		/*
		 * Employee emp1 = new Employee("Jeff Bezos", "CEO", 900000d); Employee emp2 =
		 * new Employee("Elon Gates", "CFO", 800000d); Employee emp3 = new
		 * Employee("Elon Musk", "CTO", 700000d);
		 * 
		 * List<Employee> empList = new ArrayList<>();
		 * empList.add(emp3);empList.add(emp2);empList.add(emp1);
		 * 
		 * Optional<Employee> employee = empList.stream().filter(emp->
		 * emp.getName().equals("Jeff1 Bezos")).findFirst();
		 * 
		 * System.out.println(employee.isPresent() ?
		 * employee.get().getName():"Not Found");
		 */
		
		//empList.stream().filter(emp -> emp.getName().contains("Elon")).
		
		/*
		 * IntStream stream = IntStream.of(1, 2, 3, 4, 5, 6, 7); stream.allMatch(i -> {
		 * System.out.print(i); return i % 3 == 0; });
		 */
		
        
		/*
		 * IntStream stream1 = IntStream.of(1, 2, 3, 4, 5, 6, 7); stream1.filter(i -> {
		 * return i > 3; }).anyMatch(i -> { System.out.print(i+", "); return i % 2 == 1;
		 * });
		 */ 
        
		/*
		 * IntStream stream = IntStream.of(1, 2, 3, 4, 5, 6, 7); stream.filter(i -> {
		 * return i > 3; }).anyMatch(i -> { System.out.print(i); return i % 2 == 1; });
		 */
          
		
		Date currentDate = new Date();
        System.out.println(dateFormat.format(currentDate));

        // convert date to calendar
        Calendar c = Calendar.getInstance();
        c.setTime(currentDate);

        // manipulate date
        
        c.add(Calendar.DATE, 1); 		
        Date currentDatePlusOne = c.getTime();

        String date = dateFormat.format(currentDatePlusOne);
        
        System.out.println(date);
        
	}
	
}
