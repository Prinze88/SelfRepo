package com.demo.java8;

public class BooleanTest {

	
	public static void main(String[] args) {
		
		String bool = "true";
		
		if(Boolean.valueOf(bool).equals(Boolean.TRUE)) {
			System.out.println("meow");
		}else {
			System.out.println("Woof");
		}
		
	}
}
