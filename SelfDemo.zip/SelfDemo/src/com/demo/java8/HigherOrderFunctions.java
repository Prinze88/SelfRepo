package com.demo.java8;

import java.util.Collections;
import java.util.List;

public class HigherOrderFunctions {

	
	public static void main(String[] args) {
		Employee obj = new Employee();
		List<Employee> list = obj.getEmployees();
		
		//Collections.sort(list);
		//DesignationSorting ds = new DesignationSorting();
		Collections.sort(list, (emp1,emp2)->emp1.getDesignation().compareTo(emp2.getDesignation()));
		//Collections.sort
		
		list.stream().forEach(System.out::println);
	}
	
}
