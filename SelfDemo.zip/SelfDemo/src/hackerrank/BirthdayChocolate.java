package hackerrank;

import java.util.Arrays;
import java.util.List;

public class BirthdayChocolate {

	
	static int birthday(List<Integer> s, int d, int m) {
		int count = 0;
		
		for(int i=0;i<s.size();i++) {
			int sum = 0;
			for(int j=i;((i+m)<=s.size()&& j<(i+m));j++) {
				sum +=s.get(j);
			}
			if(sum==d) {
				count++;
			}
		}
		
		return count;
    }
	
	public static void main(String[] args) {
		
		Integer[] arr = {4};
		List<Integer> s = Arrays.asList(arr);
		int d = 4,m=1;
		
		System.out.println(birthday(s, d, m));
	}
}
