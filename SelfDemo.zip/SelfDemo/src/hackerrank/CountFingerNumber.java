package hackerrank;

public class CountFingerNumber {

	public static void main(String[] args) {
		
		int number  = 15;
		
		System.out.println(getFingerNumber(number));
		
	}

	private static int getFingerNumber(int number) {
		int result = 0;
		
		int r = number%8;
		
		if(number==1)
			result = 1;
		if(number==5)
			result = 5;
		if(r==2 || r==8)
			result = 2;
		if(r==3 || r==7)
			result = 3;
		if(r==4 || r==6)
			result = 4;
		
		return result;
	}
	
	
}
