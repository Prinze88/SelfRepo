package hackerrank;

import java.util.HashMap;
import java.util.Map;


class Tq{
	
	Boolean val = null;
}


public class SalesByMatch {

	static int sockMerchant(int n, int[] ar) {
		int pairs = 0;
		Tq qt = new Tq();

		Map<Integer,Integer> mapPair = new HashMap<Integer,Integer>();

		System.out.println(qt.val);
		
		int cnt = 0;
		for (int i = 0; i < ar.length; i++) {

			if(mapPair.get(ar[i])!=null) {
				cnt =  mapPair.get(ar[i]);
				cnt = cnt+1;
				
				if(cnt%2==0)
					pairs++;
				
				mapPair.put(ar[i], cnt);
			}else {
				mapPair.put(ar[i], 1);
			}
		}

		return pairs;
	}

	public static void main(String[] args) {
		int n = 9;
		int[] arr = {10,20,20,10,10,30,50,10,20};

		System.out.println(sockMerchant(n, arr));
	}

}
