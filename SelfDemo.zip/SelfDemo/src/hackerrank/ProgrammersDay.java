package hackerrank;

public class ProgrammersDay {

	
	static String dayOfProgrammer(int year) {

		StringBuilder val = new StringBuilder(".09.").append(year);
		StringBuilder date = new StringBuilder();
		
		if(year==1918) {
			date = new StringBuilder("26.09.1918");
		}else if( (year%400==0 || (year%4==0 && year%100!=0)) || (year%4==0 && year<1918)) {
			date.append("12").append(val);
		}else {
			date.append("13").append(val);
		}
		
		return date.toString();
    }
	
	public static void main(String[] args) {
		int year = 2100;
		System.out.println(dayOfProgrammer(year));
	}
	
}
