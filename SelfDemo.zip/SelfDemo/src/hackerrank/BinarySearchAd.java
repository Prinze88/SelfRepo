package hackerrank;

public class BinarySearchAd {

	
	private static int binarySearch(int[] a, int key) {

		int lo = 0;
		int hi = a.length - 1;
		int n = a.length;

		/*
		 * while (lo <= hi) { int mid = lo + (hi - lo) / 2; if (a[mid] == key) { return
		 * mid; } else if (a[mid] < key) { lo = mid+1; } else if (a[mid] > key) { hi =
		 * mid - 1; } }
		 */
		
		while (lo <= hi) {
			int mid = lo + (hi - lo) / 2;
			if (a[mid] == key) {
				return mid;
			} else if (a[mid] < key && key < a[mid - 1]) {
				return mid;
			} else if (a[mid] > key && key >= a[mid + 1]) {
				return mid + 1;
			} else if (a[mid] < key) {
				hi = mid - 1;
			} else if (a[mid] > key) {
				lo = mid + 1;
			}
		}
		
		return -1;
	}
	
	
	public static void main(String[] args) {
		
		int[] a = {9,8,7,6,5,4,3,2,1};
		int key = 4;
		
		System.out.println(binarySearch(a, key));
	}
}
