package hackerrank;

public class Test {

	public static void main(String[] args) {

		int col = 9, row = 5;

		for(int i=0;i<row;i++) {
			for(int j=0;j<col;j++) {

				if(j== ((col/2)-i) || j== ((col/2)+i)) {
					System.out.print("1");
				}else {
					System.out.print("0");
				}
			}
			System.out.println();
		}

	}
}
