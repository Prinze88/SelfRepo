package hackerrank;

public class Kadanes {

	public static void main(String[] args) {
		
		int[] arr = new int[] {5,4,-2,-1,3,-12,4,6,7,-17,18};
		
		int sum=0, maxSum=0, startIndex=0,eleCnt=0;
		
		for(int i=0;i<arr.length;i++) {
			sum += arr[i];
			if(sum<0) {
				sum = 0;
				eleCnt = 0;
				startIndex = i+1;
			}else {
				maxSum = Math.max(sum, maxSum);
				eleCnt++;
			}
		}
		
		System.out.println(maxSum+" for range "+startIndex+" "+(startIndex+eleCnt));
		
			
	}
	
}
