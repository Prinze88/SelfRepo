package hackerrank;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class BetweenTwoSets {

	
	public static int getTotalX(List<Integer> a, List<Integer> b) {
		int total = 0;
		
		Collections.sort(a);
		Collections.sort(b);
		List<Integer> c = new ArrayList<Integer>();
		List<Integer> d = new ArrayList<Integer>();
		for(int i = 1;i<=b.get(0);i++) {
			boolean flag = false;
			for(int j = 0;j<a.size();j++) {
				if(i%a.get(j)==0) {
					flag = true;
				}else {
					flag = false;
					break;
				}
			}
			if(flag)
				c.add(i);
		}
		
		
		
		for(int t=0;t<c.size();t++) {
			boolean flag = false;
			for(int i : b) {
				if(i%c.get(t)==0) {
					flag = true;
				}else {
					flag = false;
					break;
				}
			}
			if(flag)
				d.add(c.get(t));
		}
		
		//System.out.println(d);
		total = d.size();
		return total;
	}
	
	public static void main(String[] args) {
		
		Integer[] a = {2,6};
		Integer[] b = {24,36};
		
		getTotalX(Arrays.asList(a), Arrays.asList(b));
		
	}
}
