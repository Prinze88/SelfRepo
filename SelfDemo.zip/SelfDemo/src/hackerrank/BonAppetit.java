package hackerrank;

import java.util.Arrays;
import java.util.List;

public class BonAppetit {

	static void bonAppetit(List<Integer> bill, int k, int b) {
		
		int sum = bill.stream().reduce(0,Integer::sum);
		int diff = sum - bill.get(k);
		int share = diff/2;
		
		if(share==b) {
			System.out.println("Bon Appetit");
		}else {
			System.out.println(b-share);
		}

    }
	
	public static void main(String[] args) {
	
		Integer[] arr = {3,10,2,9};
		bonAppetit(Arrays.asList(arr), 1, 12);
		
	}
	
}
