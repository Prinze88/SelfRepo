package hackerrank;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Socks {

	static int sockMerchant(int n, int[] ar) {
		int pairs =0;
		
		Map<Integer,Integer> freq = new HashMap<Integer,Integer>();
		
		for (int i = 0; i < ar.length; i++) {
			
			if(freq.containsKey(ar[i])) {
				int cnt = freq.get(ar[i]);
				freq.put(ar[i], cnt+1);
				
				if(freq.get(ar[i])%2==0)
					pairs++;
			}else {
				freq.put(ar[i], 1);
			}
		}
		return pairs;
		
		
	}

	public static void main(String[] args) {
		int[] ar = {10,20,20,10,10,30,50,10,20};
		System.out.println(sockMerchant(ar.length, ar));
		
		List<Socks> users = null;
		users.size();
	}


}
