package hackerrank;

public class DrawingBook {

	
	static int pageCount(int n, int p) {
        
        int totalTurns = n/2;
        int turnLR = p/2;
        int turnRL = totalTurns - turnLR;
        
        return Math.min(turnLR, turnRL);
        
    }
	
	
	public static void main(String[] args) {
		
		
		System.out.println(pageCount(5, 6));
	}
}
