package hackerrank;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.Stack;
import java.util.stream.IntStream;

public class ClimbingLeaderBoard {

	public static List<Integer> climbingLeaderboard(List<Integer> otherPlayerScores, List<Integer> playerScores)
	{
		List<Integer> result = new ArrayList<>();

		int n = otherPlayerScores.size();
		int[] rankArr = new int[otherPlayerScores.size()];

		rankArr[0] = 1;
		for(int i=1;i<otherPlayerScores.size();i++) {
			if(otherPlayerScores.get(i).equals(otherPlayerScores.get(i-1)))
				rankArr[i] = rankArr[i-1];
			else
				rankArr[i] = rankArr[i-1]+1;
		}


		for(Integer i : playerScores) {
			if(i>otherPlayerScores.get(0)) {
				result.add(1);
			}else if(i<otherPlayerScores.get(otherPlayerScores.size()-1)) {
				result.add(rankArr[n-1]+1);
			}else {
				int index = binarySearch(i,otherPlayerScores);
				result.add(rankArr[index]);
			}
		}

		return result;

	}


	private static int binarySearch(Integer key, List<Integer> ranked) {
		int high = ranked.size()-1;
		int low = 0;

		Integer[] scores = ranked.toArray(new Integer[0]);

		while(low<=high) {
			int mid = low + (high - low ) /2;

			if(scores[mid]==key) {
				return mid;
			}
			else if(scores[mid] < key && key < scores[mid-1]) {
				return mid;
			}
			else if(scores[mid] > key && key >= scores[mid+1]) {
				return mid+1;
			}
			else if (scores[mid] < key) {
				high = mid - 1;
			}
			else if (scores[mid] > key) {
				low = mid + 1;
			}
		}

		return -1;
	}


	public static void main(String[] args) {

		Integer[] ranked_Arr = {100,100,50,40,40,20,10};
		Integer[] player_Arr = {5,25,50,120};

		System.out.println(climbingLeaderboard(Arrays.asList(ranked_Arr), Arrays.asList(player_Arr)));

	}

}
