package hackerrank;

public class Kangaroo {

	
	static String kangarooJump(int x1, int v1, int x2, int v2) {
		String output ="";
		int cnt = v1;
		
		if(x2>x1 && v2 > v1)
			output = "NO";
		else if(x2==x1 && v2==v1)
			output = "YES";
		else {
			
		boolean flag = false;
		for(int i=x1,j=x2;i<10000000&&j<10000000;i+=v1,j+=v2) {
			if(i==j) {
				output = "YES";
				flag = true;
				break;
			}
			
		}
		
		if(!flag)
			output = "NO";
		
		}	
			
		return output;

    }
	
	
	public static void main(String[] args) {
		
		//System.out.println(kangarooJump(0, 3, 4, 2));
		//System.out.println(kangarooJump(28, 8, 96, 2));
		//System.out.println(kangarooJump(21, 6, 47, 3));
		System.out.println(kangarooJump(14, 4, 98, 2));
		
		
	}
}
