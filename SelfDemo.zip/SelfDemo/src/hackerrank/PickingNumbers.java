package hackerrank;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class PickingNumbers {

	public static int pickingNumbers(List<Integer> a) {
		int result = Integer.MIN_VALUE;
		int[] freq = new int[101]; 
		
		for(int i : a) {
			freq[i]++;
		}
		
		
		for(int i=1;i<=100;i++) {
			result = Math.max(result,freq[i]+freq[i-1]);
		}
		
		
		return result;
	}



	public static void main(String[] args) {
		
		Integer[] a = {4,6,5,3,3,1};
		List<Integer> list = Arrays.asList(a);
		System.out.println(pickingNumbers(list));
		
	}

}
