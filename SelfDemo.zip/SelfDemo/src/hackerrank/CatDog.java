package hackerrank;

public class CatDog {
	
	 
    static String catAndMouse(int x, int y, int z) {
    	
    	final String CAT_A = "Cat A";
    	final String CAT_B = "Cat B";
    	final String MOUSE_C = "Mouse C";
    	
    	
    	if(Math.abs(x-z) < Math.abs(y-z))
    		return CAT_A;
    	else if(Math.abs(x-z) > Math.abs(y-z))
    		return CAT_B;
    	else
    		return MOUSE_C;
    }


    public static void main(String[] args) {
		System.out.println(catAndMouse(2, 5, 4));
	}
	
}
