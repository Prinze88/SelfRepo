package hackerrank;

import java.util.Arrays;

public class BreakingTheRecord {

	static int[] breakingRecords(int[] scores) {
		int[] records = new int[2];
		
		int max = scores[0],min = scores[0], maxCount=0,minCount=0;
		
		
		
		for (int i = 1; i < scores.length; i++) {
			if(scores[i]<min) {
				minCount++;
				min = scores[i];
			}
			
			if(scores[i]>max) {
				maxCount++;
				max = scores[i];
			}
			
			records[0] = maxCount;
			records[1] = minCount;
			
		}
		
		return records;
		
    }
	
	
	public static void main(String[] args) {
	
		int arr[] = {3,4,21,36,10,28,35,5,24,42};
		System.out.println(Arrays.toString(breakingRecords(arr)));		
	}
	
}
