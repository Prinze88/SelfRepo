package hackerrank;

import static java.util.stream.Collectors.toList;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class MigratoryBirds {

	static Long migratoryBirds(List<Integer> arr) {
		Long count = Long.MIN_VALUE;
		Long max = Long.MIN_VALUE;


		Map<Integer,Long> val = arr.stream()
				.collect(Collectors
						.groupingBy(Function.identity(),Collectors.counting()));

		System.out.println(val);

		for(Integer i : val.keySet()) {
			if(val.get(i)>max) {
				count = Long.parseLong(i+"");
				max = val.get(i);
			}
		}

		return count;

	}

	public static void main(String[] args) throws IOException {
		BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(System.in));
		List<Integer> arr = Stream.of(bufferedReader.readLine().replaceAll("\\s+$", "").split(" "))
				.map(Integer::parseInt)
				.collect(toList());

		Long result = migratoryBirds(arr);

		System.out.println(String.valueOf(result));


		bufferedReader.close();
	}

}
