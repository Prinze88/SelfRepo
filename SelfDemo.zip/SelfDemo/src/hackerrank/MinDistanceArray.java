package hackerrank;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MinDistanceArray {
	// 7 1 3 4 1 7 
	static int minimumDistances(int[] a) {

		int min = -1;
		List<Integer> list = new ArrayList<Integer>();
		Map<Integer,Integer> numberPos = new HashMap<Integer,Integer>();
		Map<Integer,Integer> minNumberPos = new HashMap<Integer,Integer>();
		
		for (int i = 0; i < a.length; i++) {
			if(!numberPos.containsKey(new Integer(a[i]))) {
				numberPos.put(new Integer(a[i]),i);
			}else {
				int prevPos = numberPos.get(a[i]);
				minNumberPos.put(a[i], i-prevPos);
			}
		}
		
		if(minNumberPos.isEmpty())
			min = -1;
		else {
			int tempMin = Integer.MAX_VALUE;
			for(int i : minNumberPos.keySet()) {
				
				if(minNumberPos.get(i)<tempMin) {
					tempMin = minNumberPos.get(i);
				}
			}
			min = tempMin;
		}
		
		//System.out.println(minNumberPos);
		return min;
    }
	
	
	public static void main(String[] args) {
		
		int arr[] = {7,1,3,4,1,7};
		
		System.out.println(minimumDistances(arr));
	}
	
}
