package hackerrank;

public class CountingValleys {

	static int count(int n ,String s) {
		int alt = 0;
		int numValleys = 0;
		int numPeaks = 0;
		
		for(int i=0;i<s.length();i++) {
			if(s.charAt(i)=='U') {
				if(alt==-1) {
					numValleys++;
				}
				alt++;
			}else {
				if(alt==1) {
					numPeaks++;
				}
				alt--;
			}
		}
		
		return numValleys;
	}
	
	public static void main(String[] args) {
		//System.out.println(count(8,"UDDDUDUU"));
		System.out.println(count(8,"DDUUUUDD"));
	}
}
